# Crear la regla de firewall
New-NetFirewallRule -DisplayName "SDIO-Drivers" -Enabled True -Direction Outbound -Profile Any -Action Allow -Program (Get-ChildItem -Path "$env:TEMP\SnappyDriver" -Recurse -Filter "SDIO_x64_R746.exe" | Select-Object -First 1).FullName | Out-Null

# Ejecutar SDI_x64_R2503.exe con el script update-install.txt
.\(Get-ChildItem -Path "$env:TEMP\SnappyDriver" -Recurse -Filter "SDI_x64_R2503.exe" | Select-Object -First 1).Name /script:(Get-ChildItem -Path "$env:TEMP\SnappyDriver" -Recurse -Filter "update-install.txt" | Select-Object -First 1).FullName

# Esperar 10 segundos
Start-Sleep -Seconds 10

# Ejecutar nuevamente SDI_x64_R2503.exe con el script update-install.txt
.\(Get-ChildItem -Path "$env:TEMP\SnappyDriver" -Recurse -Filter "SDI_x64_R2503.exe" | Select-Object -First 1).Name /script:(Get-ChildItem -Path "$env:TEMP\SnappyDriver" -Recurse -Filter "update-install.txt" | Select-Object -First 1).Full
