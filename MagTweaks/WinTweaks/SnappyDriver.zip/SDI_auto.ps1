New-NetFirewallRule -DisplayName "SDIO-Drivers" -Enabled True -Direction Outbound -Profile Any -Action Allow -Program "C:\scripts\SDIO\SDIO_x64_R746.exe" | Out-Null

.\SDI_x64_R2503.exe /script:C:\Users\Mangus\Downloads\SDI_R2503\update-install.txt
Start-Sleep -Seconds 10
.\SDI_x64_R2503.exe /script:C:\Users\Mangus\Downloads\SDI_R2503\update-install.txt